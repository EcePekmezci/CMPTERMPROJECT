#include <vector>

class BulwarkOfFaith : public UtilitySkill {
public:

BulwarkOfFaith();
~BulwarkOfFaith();

int BulwarkOfFaithBuff(int protection);

};
