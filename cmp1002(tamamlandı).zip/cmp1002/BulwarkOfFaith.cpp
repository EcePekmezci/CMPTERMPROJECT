#include "Skills.h"
#include "UtilitySkill.h"
#include "BulwarkOfFaith.h"

BulwarkOfFaith::BulwarkOfFaith(){}
BulwarkOfFaith::~BulwarkOfFaith(){}


int BulwarkOfFaith::BulwarkOfFaithBuff(int protection){

protection =+ 20;

return protection;
};
