class BoneSoldier : public Monster {
public:

BoneSoldier(int a);

~BoneSoldier(){
// cout << "BoneSoldier has been destroyed" << endl;
}


};
