#ifndef VESTAL_H
#define VESTAL_H

class Vestal : public Hero {
public:

Vestal(int a);
~Vestal();

};

#endif // VESTAL_H
