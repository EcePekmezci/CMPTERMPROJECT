#ifndef ATTACKSKILL_H
#define ATTACKSKILL_H
#include "Hero.h"
#include "Monster.h"

class AttackSkill : public Skills {
public:

};


#endif // ATTACKSKILL_H
