#ifndef SKILLS_H
#define SKILLS_H

class Skills {

public:


};

#endif // SKILLS_H
