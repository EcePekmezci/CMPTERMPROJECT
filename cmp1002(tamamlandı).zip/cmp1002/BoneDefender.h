
class BoneDefender : public Monster {
public:

BoneDefender(int a);

~BoneDefender(){
//cout << "BoneDefender has been destroyed" << endl;
}
    };
