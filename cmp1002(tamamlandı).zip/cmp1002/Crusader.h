#ifndef CRUSADER_H
#define CRUSADER_H

#include "Hero.h"
class Crusader : public Hero {
public:

Crusader(int a);

~Crusader();



};


#endif // CRUSADER_H
