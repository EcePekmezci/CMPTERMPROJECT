#ifndef UTILITYSKILL_H
#define UTILITYSKILL_H
#include "Hero.h"
#include "Monster.h"

class UtilitySkill : public Skills {
    public:

 };

#endif
